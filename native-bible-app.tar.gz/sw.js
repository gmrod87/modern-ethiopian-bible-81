const V='meb-native-v1';
const SHELL=['/','/index.html','/styles.css','/app.js','/books.json','/ot.b64','/eth.b64','/nt.b64','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png','/icons/apple-touch-icon.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(res=>{if(res.ok&&new URL(e.request.url).origin===location.origin){const copy=res.clone();caches.open(V).then(c=>c.put(e.request,copy))}return res}).catch(()=>caches.match('/index.html'))))});
