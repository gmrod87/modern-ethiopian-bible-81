const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const app=$('#app');
let books=[], bookMap=new Map(), currentBook=null, currentChapter=null, selectedVerse=null;
let corpora={ot:null,eth:null,nt:null}, speech={token:0,index:0,playing:false,paused:false,verses:[]};

const categoryName={ot:'Old Testament',eth:'Ethiopian Canon',nt:'New Testament'};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const divine=s=>esc(s).replace(/\b(YHWH|Jesus)\b/g,'<span class="divine">$1</span>');
const route=(slug,c=1,v='')=>`#read/${slug}/${c}${v?'/'+v:''}`;
const safeJSON=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(d))}catch{return d}};
const user=()=>safeJSON('meb:user',{saved:[],notes:{}});
function saveUser(d){localStorage.setItem('meb:user',JSON.stringify(d));updateSavedBadge()}
function toast(t){const x=$('#toast');x.textContent=t;x.classList.add('show');clearTimeout(x._t);x._t=setTimeout(()=>x.classList.remove('show'),1800)}
function setLoading(t='Opening…'){app.innerHTML=`<div class="loading"><div class="spinner"></div><p>${esc(t)}</p></div>`}

async function init(){
  books=await fetch('/books.json').then(r=>r.json());
  books.forEach((b,i)=>{b.order=i+1;bookMap.set(b.slug,b)});
  renderDrawer(); updateSavedBadge(); populateVoices();
  if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
  window.addEventListener('hashchange',router);
  router();
}

function renderDrawer(filter='all'){
  const list=books.filter(b=>filter==='all'||b.category===filter);
  $('#drawerBooks').innerHTML=list.map(b=>`<a class="drawerBook" href="${route(b.slug,1)}"><i>${String(b.order).padStart(2,'0')}</i><span>${esc(b.title)}</span><small>${b.chapters.length} ch.</small></a>`).join('');
  $$('#drawerBooks a').forEach(a=>a.addEventListener('click',closeDrawer));
}
function openDrawer(filter='all'){$('#drawer').classList.add('open');$('#backdrop').classList.add('open');$('#drawer').setAttribute('aria-hidden','false');setFilter(filter)}
function closeDrawer(){$('#drawer').classList.remove('open');$('#backdrop').classList.remove('open');$('#drawer').setAttribute('aria-hidden','true')}
function setFilter(f){$$('#filters button').forEach(b=>b.classList.toggle('active',b.dataset.filter===f));renderDrawer(f)}

function router(){
  closeDrawer(); stopAudio(false);
  const h=location.hash||'#home';
  if(h==='#home') return renderHome();
  if(h.startsWith('#read/')){const p=h.slice(6).split('/');return renderChapter(p[0],+(p[1]||1),p[2]?+p[2]:null)}
  if(h.startsWith('#book/')) return renderBookOverview(h.slice(6));
  if(h.startsWith('#search/')) return renderSearch(decodeURIComponent(h.slice(8)));
  renderHome();
}

function daily(){const d=new Date(), n=(Math.floor(d.getTime()/86400000)%150)+1;return {slug:'psalms',chapter:n}}
function renderHome(){
  const last=safeJSON('meb:last',null), d=daily(), u=user(), saved=u.saved.length, notes=Object.keys(u.notes).length;
  const featured=[['genesis','THE BEGINNING','Genesis',1],['psalms','PRAYER & POETRY','Psalms',23],['jubilees','ETHIOPIAN CANON','Jubilees',1],['1-enoch','ETHIOPIAN CANON','1 Enoch',1],['matthew','GOSPEL','Matthew',1],['revelation','APOCALYPSE','Revelation',1]];
  app.innerHTML=`
  <section class="hero">
    <div class="ornament"><span>✦</span><i></i><b>፨</b><i></i><span>✦</span></div>
    <span class="eyebrow">81-BOOK RESEARCH EDITION • SEARCH • READ • LISTEN</span>
    <h1>Modern<br><em>Ethiopian</em> Bible</h1>
    <p>Your complete Bible now lives inside the app as native searchable text. No PDF chooser, no page-by-page parsing, no waiting for a 1,928-page document to open.</p>
    <div class="heroActions"><a class="primary" href="${route(last?.slug||'genesis',last?.chapter||1,last?.verse||'')}">${last?'Continue reading':'Begin with Genesis'}</a><button class="pill" id="heroBrowse">Browse all 81 books</button></div>
    <div class="nativeBadge"><i></i><span>Native text edition • instant book & chapter opening</span></div>
  </section>
  <section class="section"><div class="sectionHead"><div><span class="eyebrow">YOUR READING</span><h2>Continue & discover</h2></div></div>
    <div class="continueGrid">
      <a class="featureCard heroCard" href="${route(last?.slug||'genesis',last?.chapter||1)}"><span class="eyebrow">CONTINUE</span><b>${esc(last?`${last.title} ${last.chapter}`:'Genesis 1')}</b><small>${last?'Your place is saved automatically':'Start at the beginning'}</small><span class="arrow">→</span></a>
      <a class="featureCard" href="${route(d.slug,d.chapter)}"><span class="eyebrow">DAILY READING</span><b>Psalm ${d.chapter}</b><small>A psalm selected for today</small><span class="arrow">→</span></a>
      <button class="featureCard" id="homeLibrary"><span class="eyebrow">YOUR LIBRARY</span><b>${saved} saved</b><small>${notes} personal note${notes===1?'':'s'}</small><span class="arrow">→</span></button>
    </div>
  </section>
  <section class="section"><div class="sectionHead"><div><span class="eyebrow">EXPLORE</span><h2>Browse the Bible</h2></div><button class="textLink" id="seeAll">See all books →</button></div>
    <div class="categoryGrid">
      <button class="category" data-cat="ot"><span class="num">01</span><b>Old Testament</b><small>Torah, histories, wisdom and prophets</small></button>
      <button class="category" data-cat="eth"><span class="num">02</span><b>Ethiopian Books</b><small>Jubilees, Enoch, Meqabyan and more</small></button>
      <button class="category" data-cat="nt"><span class="num">03</span><b>New Testament</b><small>Matthew through Revelation</small></button>
      <button class="category" data-cat="all"><span class="num">04</span><b>Complete 81 Books</b><small>The entire native reading edition</small></button>
    </div>
  </section>
  <section class="section"><div class="sectionHead"><div><span class="eyebrow">QUICK OPEN</span><h2>Featured books</h2></div></div><div class="featuredBooks">${featured.map(x=>`<a class="bookTile" href="${route(x[0],x[3])}"><span>${x[1]}</span><b>${x[2]}</b><small>Chapter ${x[3]}</small></a>`).join('')}</div></section>
  <div class="editionStats"><div><b>81</b><small>books</small></div><div><b>${books.reduce((n,b)=>n+b.chapters.length,0).toLocaleString()}</b><small>chapters</small></div><div><b>36k+</b><small>verse records</small></div><div><b>Audio</b><small>read aloud</small></div></div>
  <div class="researchNote"><b>Research edition.</b> The edition keeps Ethiopian-canon material and manuscript/source notes visible instead of silently presenting every textual layer as the same kind of source.</div>`;
  $('#heroBrowse').onclick=()=>openDrawer('all'); $('#seeAll').onclick=()=>openDrawer('all'); $('#homeLibrary').onclick=openLibrary;
  $$('.category').forEach(x=>x.onclick=()=>openDrawer(x.dataset.cat));
  scrollTo({top:0});
}

async function loadCorpus(cat){
  if(corpora[cat])return corpora[cat];
  const b64=await fetch(`/${cat}.b64`).then(r=>{if(!r.ok)throw Error('Corpus unavailable');return r.text()});
  const raw=atob(b64.trim()), bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
  if(!('DecompressionStream' in window))throw Error('This browser is too old for the native Bible data. Please update it.');
  const ds=new DecompressionStream('gzip');
  const text=await new Response(new Blob([bytes]).stream().pipeThrough(ds)).text();
  corpora[cat]=JSON.parse(text);
  return corpora[cat];
}
async function fetchBook(slug){
  if(currentBook?.slug===slug && currentBook.chapters?.[0]?.verses) return currentBook;
  const m=bookMap.get(slug);if(!m)throw Error('Unknown book');const corpus=await loadCorpus(m.category);const b=corpus[slug];if(!b)throw Error('Book data unavailable');currentBook=b;return b;
}

async function renderBookOverview(slug){
  const meta=bookMap.get(slug); if(!meta)return renderHome(); setLoading(`Opening ${meta.title}…`); const b=await fetchBook(slug);
  app.innerHTML=`<section class="reader"><div class="readerHead"><span class="breadcrumb">${categoryName[b.category]}</span><h1>${esc(b.title)}</h1><p>${b.chapters.length} chapters • choose a chapter</p></div><div class="chapterGrid">${b.chapters.map(c=>`<a href="${route(slug,c.n)}">${c.n}</a>`).join('')}</div></section>`; scrollTo({top:0});
}

async function renderChapter(slug,cnum,verseJump=null){
  const meta=bookMap.get(slug); if(!meta)return renderHome(); setLoading(`Opening ${meta.title} ${cnum}…`);
  let b; try{b=await fetchBook(slug)}catch(e){app.innerHTML=`<div class="loading"><p>Couldn't load this book. Please refresh.</p></div>`;return}
  let c=b.chapters.find(x=>x.n===cnum)||b.chapters[0]; currentChapter=c;
  const ci=b.chapters.findIndex(x=>x.n===c.n), prev=b.chapters[ci-1], next=b.chapters[ci+1];
  const metaBook=bookMap.get(slug), ps=b.title==='Psalms';
  localStorage.setItem('meb:last',JSON.stringify({slug,title:b.title,chapter:c.n,verse:verseJump||null}));
  const verseHTML=c.verses.length?c.verses.map(v=>`<p class="verse" id="v${v.v}" data-v="${v.v}"><button class="vnum" title="Verse actions">${v.v}</button>${divine(v.t)}</p>`).join(''):`<p>${divine(c.note||'No parsed verse text is available for this chapter.')}</p>`;
  app.innerHTML=`<section class="reader">
    <div class="readerHead"><span class="breadcrumb">${categoryName[b.category]} • BOOK ${String(metaBook.order).padStart(2,'0')}</span><h1>${esc(b.title)}</h1><p>${ps?'Psalm':'Chapter'} ${c.n}${c.label && c.label!==`${b.title} ${c.n}`?` • ${esc(c.label)}`:''}</p></div>
    <div class="readerTools"><select id="bookSelect" class="bookSelect">${books.map(x=>`<option value="${x.slug}" ${x.slug===slug?'selected':''}>${esc(x.title)}</option>`).join('')}</select><select id="chapterSelect">${b.chapters.map(x=>`<option value="${x.n}" ${x.n===c.n?'selected':''}>${ps?'Psalm':'Chapter'} ${x.n}</option>`).join('')}</select><select id="verseSelect"><option value="">Verse</option>${c.verses.map(v=>`<option value="${v.v}">${v.v}</option>`).join('')}</select><button id="fontMinus">A−</button><button id="fontPlus">A+</button><button id="listenChapter">◉ Listen</button></div>
    <article class="chapterText" id="chapterText">${verseHTML}${c.note&&c.verses.length?`<aside class="chapterNote">${divine(c.note)}</aside>`:''}</article>
    <div class="readerPager">${prev?`<a href="${route(slug,prev.n)}">← ${ps?'Psalm':'Chapter'} ${prev.n}</a>`:'<span></span>'}<button id="saveChapter">♡ Save chapter</button>${next?`<a href="${route(slug,next.n)}">${ps?'Psalm':'Chapter'} ${next.n} →</a>`:'<span></span>'}</div>
    <div class="sectionHead" style="margin-top:35px"><div><span class="eyebrow">CHAPTERS</span><h2>${esc(b.title)}</h2></div></div><div class="chapterGrid">${b.chapters.map(x=>`<a class="${x.n===c.n?'current':''}" href="${route(slug,x.n)}">${x.n}</a>`).join('')}</div>
  </section>`;
  $('#bookSelect').onchange=e=>location.hash=route(e.target.value,1);
  $('#chapterSelect').onchange=e=>location.hash=route(slug,+e.target.value);
  $('#verseSelect').onchange=e=>{const el=document.getElementById('v'+e.target.value);el?.scrollIntoView({behavior:'smooth',block:'center'});el?.classList.add('active');setTimeout(()=>el?.classList.remove('active'),1600)};
  $('#fontMinus').onclick=()=>adjustFont(-1); $('#fontPlus').onclick=()=>adjustFont(1); $('#listenChapter').onclick=()=>startAudio(c.verses,0,b.title,c.n);
  $('#saveChapter').onclick=()=>toggleSaveChapter(b,c);
  $$('.verse').forEach(el=>el.addEventListener('click',e=>{if(e.target.closest('.vnum')||e.target===el)openVerseDialog(b,c,+el.dataset.v)}));
  $('#chapterText').addEventListener('dblclick',e=>{const el=e.target.closest('.verse');if(el)openVerseDialog(b,c,+el.dataset.v)});
  if(verseJump){setTimeout(()=>{const el=document.getElementById('v'+verseJump);el?.scrollIntoView({behavior:'smooth',block:'center'});el?.classList.add('active')},120)} else scrollTo({top:0});
}

function adjustFont(d){const r=document.documentElement, cur=parseInt(getComputedStyle(r).getPropertyValue('--reader'))||20, n=Math.max(15,Math.min(31,cur+d));r.style.setProperty('--reader',n+'px');localStorage.setItem('meb:font',n)}
const savedFont=+localStorage.getItem('meb:font'); if(savedFont)document.documentElement.style.setProperty('--reader',savedFont+'px');

function openVerseDialog(b,c,vnum){
  const v=c.verses.find(x=>x.v===vnum); if(!v)return; selectedVerse={book:b,chapter:c,verse:v}; const ref=`${b.title} ${c.n}:${v.v}`, d=user();
  $('#verseDialogRef').textContent=ref; $('#verseDialogText').textContent=v.t; $('#verseNote').value=d.notes[ref]||'';
  $('#saveVerse').textContent=d.saved.some(x=>x.ref===ref)?'♥ Saved':'♡ Save'; $('#verseDialog').showModal();
}
function toggleSaveChapter(b,c){const d=user(),ref=`${b.title} ${c.n}`,i=d.saved.findIndex(x=>x.ref===ref&&x.type==='chapter');if(i>=0){d.saved.splice(i,1);toast('Chapter removed')}else{d.saved.unshift({type:'chapter',ref,slug:b.slug,chapter:c.n,text:''});toast('Chapter saved')}saveUser(d)}
function updateSavedBadge(){const d=user();$('#savedBtn').textContent=d.saved.length?'♥':'♡'}
function openLibrary(){const d=user(), notes=Object.entries(d.notes);$('#libraryContent').innerHTML=(d.saved.length||notes.length)?`${d.saved.map(x=>`<div class="libraryItem"><a href="${route(x.slug,x.chapter,x.verse||'')}">${esc(x.ref)}</a>${x.text?`<p>${esc(x.text.slice(0,240))}</p>`:''}</div>`).join('')}${notes.length?'<h3>Notes</h3>':''}${notes.map(([ref,text])=>{const s=d.saved.find(x=>x.ref===ref);return `<div class="libraryItem">${s?`<a href="${route(s.slug,s.chapter,s.verse||'')}">${esc(ref)}</a>`:`<b>${esc(ref)}</b>`}<p>${esc(text)}</p></div>`}).join('')}`:'<p>You have no saved verses or notes yet. Tap a verse number while reading.</p>';$('#libraryDialog').showModal()}

async function renderSearch(q){
  q=q.trim(); if(!q){location.hash='#home';return} setLoading('Searching all 81 books…');
  try{await Promise.all(['ot','eth','nt'].map(loadCorpus))}catch{app.innerHTML='<div class="loading"><p>Native Bible text could not be loaded.</p></div>';return}
  const terms=q.toLowerCase().split(/\s+/).filter(Boolean), exact=q.toLowerCase(); let hits=[];
  outer: for(const cat of ['ot','eth','nt']) for(const b of Object.values(corpora[cat])) for(const c of b.chapters) for(const v of c.verses){
    const t=v.t.toLowerCase();
    if(terms.every(k=>t.includes(k))){let score=t.includes(exact)?3:1;if(t.startsWith(exact))score+=2;hits.push({b:b.title,s:b.slug,c:c.n,v:v.v,t:v.t,score});if(hits.length>500)break outer}
  }
  hits.sort((a,b)=>b.score-a.score); const shown=hits.slice(0,120);
  app.innerHTML=`<section class="searchResults"><span class="eyebrow">WHOLE-BIBLE SEARCH</span><h1>“${esc(q)}”</h1><div class="searchMeta">${hits.length}${hits.length>=500?'+' :''} matches • showing ${shown.length}</div>${shown.length?shown.map(x=>`<a class="searchResult" href="${route(x.s,x.c,x.v)}"><b>${esc(x.b)} ${x.c}:${x.v}</b><p>${highlight(x.t,terms)}</p></a>`).join(''):'<p>No matching verses found.</p>'}</section>`;scrollTo({top:0});
}
function highlight(t,terms){let s=esc(t);for(const k of terms){const re=new RegExp('('+k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig');s=s.replace(re,'<mark>$1</mark>')}return s}

function populateVoices(){if(!('speechSynthesis'in window))return;const fill=()=>{const vs=speechSynthesis.getVoices().filter(v=>/^en[-_]/i.test(v.lang)||/English/i.test(v.name));vs.sort((a,b)=>voiceRank(b)-voiceRank(a));$('#voiceSelect').innerHTML=vs.map((v,i)=>`<option value="${esc(v.name)}">${esc(v.name.replace(/Microsoft |Google /g,''))}</option>`).join('');if(vs[0])$('#voiceSelect').value=vs[0].name};fill();speechSynthesis.onvoiceschanged=fill}
function voiceRank(v){const n=v.name.toLowerCase();let s=0;if(/natural|premium|enhanced/.test(n))s+=20;if(/samantha|daniel|karen|serena|ava|siri/.test(n))s+=10;if(/google|microsoft/.test(n))s+=5;if(v.localService)s+=2;return s}
function getVoice(){return speechSynthesis.getVoices().find(v=>v.name===$('#voiceSelect').value)||speechSynthesis.getVoices().find(v=>/^en/i.test(v.lang))}
function startAudio(vs,start,book,chapter){if(!('speechSynthesis'in window)||!vs.length)return toast('Read aloud is not supported here');stopAudio(false);speech={token:speech.token+1,index:start,playing:true,paused:false,verses:vs,book,chapter};$('#audioBar').classList.remove('hidden');$('#audioRef').textContent=`${book} ${chapter}`;speakCurrent()}
function speakCurrent(){if(!speech.playing||speech.index<0||speech.index>=speech.verses.length)return finishAudio();const token=speech.token,v=speech.verses[speech.index],u=new SpeechSynthesisUtterance(v.t);u.rate=+$('#rateSelect').value;const voice=getVoice();if(voice)u.voice=voice;u.onstart=()=>{if(token!==speech.token)return;$('#audioState').textContent=`Verse ${v.v} • ${speech.index+1} of ${speech.verses.length}`;$('#audioPlay').textContent='Ⅱ';$$('.speaking').forEach(x=>x.classList.remove('speaking'));const el=document.getElementById('v'+v.v);el?.classList.add('speaking');el?.scrollIntoView({behavior:'smooth',block:'center'})};u.onend=()=>{if(token!==speech.token)return;speech.index++;speakCurrent()};u.onerror=()=>{if(token!==speech.token)return;speech.index++;speakCurrent()};speechSynthesis.speak(u)}
function pauseResume(){if(!speech.playing)return;if(speechSynthesis.paused){speechSynthesis.resume();speech.paused=false;$('#audioPlay').textContent='Ⅱ'}else{speechSynthesis.pause();speech.paused=true;$('#audioPlay').textContent='▶';$('#audioState').textContent='Paused'}}
function finishAudio(){speech.playing=false;$('#audioState').textContent='Finished';$('#audioPlay').textContent='▶';$$('.speaking').forEach(x=>x.classList.remove('speaking'))}
function stopAudio(hide=true){speech.token++;speech.playing=false;speech.paused=false;if('speechSynthesis'in window)speechSynthesis.cancel();$$('.speaking').forEach(x=>x.classList.remove('speaking'));$('#audioPlay').textContent='▶';$('#audioState').textContent='Ready';if(hide)$('#audioBar').classList.add('hidden')}
function jumpAudio(d){if(!speech.verses.length)return;speech.token++;speechSynthesis.cancel();speech.index=Math.max(0,Math.min(speech.verses.length-1,speech.index+d));speech.playing=true;speakCurrent()}

$('#menuBtn').onclick=()=>openDrawer('all');$('#closeDrawer').onclick=closeDrawer;$('#backdrop').onclick=closeDrawer;$$('#filters button').forEach(b=>b.onclick=()=>setFilter(b.dataset.filter));
$('#savedBtn').onclick=openLibrary;$('#themeBtn').onclick=()=>{document.body.classList.toggle('dark');localStorage.setItem('meb:dark',document.body.classList.contains('dark')?'1':'0')};if(localStorage.getItem('meb:dark')==='1')document.body.classList.add('dark');
$('#searchForm').onsubmit=e=>{e.preventDefault();const q=$('#searchInput').value.trim();if(q)location.hash='#search/'+encodeURIComponent(q)};
$('#copyVerse').onclick=async()=>{if(!selectedVerse)return;const {book,chapter,verse}=selectedVerse,txt=`${book.title} ${chapter.n}:${verse.v} — ${verse.t}`;await navigator.clipboard.writeText(txt);toast('Verse copied')};
$('#shareVerse').onclick=async()=>{if(!selectedVerse)return;const {book,chapter,verse}=selectedVerse,txt=`${book.title} ${chapter.n}:${verse.v} — ${verse.t}`;if(navigator.share)await navigator.share({title:`${book.title} ${chapter.n}:${verse.v}`,text:txt,url:location.origin+route(book.slug,chapter.n,verse.v)});else{await navigator.clipboard.writeText(txt);toast('Copied for sharing')}};
$('#saveVerse').onclick=()=>{if(!selectedVerse)return;const {book,chapter,verse}=selectedVerse,ref=`${book.title} ${chapter.n}:${verse.v}`,d=user(),i=d.saved.findIndex(x=>x.ref===ref&&x.type==='verse');if(i>=0){d.saved.splice(i,1);toast('Removed from saved')}else{d.saved.unshift({type:'verse',ref,slug:book.slug,chapter:chapter.n,verse:verse.v,text:verse.t});toast('Verse saved')}saveUser(d);$('#saveVerse').textContent=i>=0?'♡ Save':'♥ Saved'};
$('#saveNote').onclick=()=>{if(!selectedVerse)return;const {book,chapter,verse}=selectedVerse,ref=`${book.title} ${chapter.n}:${verse.v}`,d=user(),t=$('#verseNote').value.trim();if(t)d.notes[ref]=t;else delete d.notes[ref];if(t&&!d.saved.some(x=>x.ref===ref))d.saved.unshift({type:'verse',ref,slug:book.slug,chapter:chapter.n,verse:verse.v,text:verse.t});saveUser(d);toast(t?'Note saved':'Note cleared')};
$('#listenVerse').onclick=()=>{if(!selectedVerse)return;const {book,chapter,verse}=selectedVerse;$('#verseDialog').close();const i=chapter.verses.findIndex(v=>v.v===verse.v);startAudio(chapter.verses,i,book.title,chapter.n)};
$('#audioPlay').onclick=()=>speech.playing?pauseResume():speech.verses.length?(speech.playing=true,speakCurrent()):null;$('#audioPrev').onclick=()=>jumpAudio(-1);$('#audioNext').onclick=()=>jumpAudio(1);$('#audioClose').onclick=()=>stopAudio(true);

init().catch(e=>{console.error(e);app.innerHTML='<div class="loading"><p>The Bible app could not start. Refresh the page.</p></div>'});
